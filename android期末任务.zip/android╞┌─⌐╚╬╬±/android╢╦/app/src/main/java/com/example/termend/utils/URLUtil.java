package com.example.termend.utils;

import android.util.Log;

import com.example.termend.activity.LoginActivity;
import com.example.termend.entity.Result;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class URLUtil {
//public static final String PATH = "http://172.29.251.50:8080/termend_war_exploded/";
   public static final String PATH = "http://123.249.14.197:8080/termend_war/";
    public static final String REQUEST_METHOD_POST="POST";
    public static final String REQUEST_METHOD_GET = "GET";

}
